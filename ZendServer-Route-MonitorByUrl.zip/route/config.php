<?php
return array(
    'http://172.17.0.2/disable/monitor/with/route/plugin/mem.php' => ZEND_MONITOR_ETBM_ALL & ~ZEND_MONITOR_ETBM_REQ_LARGE_MEM_USAGE
);
